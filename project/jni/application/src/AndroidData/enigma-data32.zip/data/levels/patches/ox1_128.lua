set_stone("st-magic", 9,5)
