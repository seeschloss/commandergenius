set_item ("it-document", 10, 2, {text="Welcome to Enigma's Per.Oxyd emulator!"})
