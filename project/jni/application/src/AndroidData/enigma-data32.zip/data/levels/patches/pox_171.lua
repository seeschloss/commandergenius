set_stone("st-polarswitch",8,0)
set_stone("st-polarswitch",11,0)
